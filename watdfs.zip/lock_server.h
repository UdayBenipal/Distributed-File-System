#ifndef LOCK_SERVER_H
#define LOCK_SERVER_H

int rpc_lock_server_register();

#endif
