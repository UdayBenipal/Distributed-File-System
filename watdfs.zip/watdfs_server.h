#ifndef WATDFS_SERVER_H
#define WATDFS_SERVER_H

void set_server_persist_dir(char * dir);

int rpc_watdfs_server_register();

#endif
